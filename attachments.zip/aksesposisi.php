 <?php 
	require_once("function.php");
 ?>
 <!DOCTYPE html>
<html>
<head>	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Akses Posisi</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="icon" type="image/png" href="image/tobatransbiru.png">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="jquery/jquery-3.2.1.min.js">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script src="bootstrap/js/bootstrap.min.js"></script>

	<!--  -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/ajax/libs/jquery/3.2.1/jquery.min.js">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 	
<!--  -->
<style type="text/css">
	img
</style>
</head>
<body>
	<?php 
	require_once("header.php");
	?>
</div>
<section id="pilihan">
	<div class="container">
		<div class="row">
			<div id="menulayanan">
				<div class="col-sm-6">
				<h4>
					Daftar Pemesanan
				</h4>
				<h6 style="color: blue">Mobil ini sedang menuju ke posisi anda</h6>
				<img src="image/1.jpg" style="width: 230px">
				</a>
				<br>
				<table>
					<th>
						<img src="image/1.jpg" style="width: 120px">
					</th>
					<th></th>
					<th>
						<p>Parlindungan Sinaga</p>
						<p>BB 1240 NJ</p>
						<button>Batalkan Pemesanan</button>
					</th>
				</table>
				</div>
			</div>
			<div class="col-sm-6">
				<div id="menulayanan">			
					<p>Lokasi</p>
				</div>
			</div>
		</div>
	</div>
</section>
	<?php 
	require_once ("footer.php");
	 ?>
</body>
</html>