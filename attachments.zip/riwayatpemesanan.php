 <?php 
	require_once("function.php");
 ?>
 <!DOCTYPE html>
<html>
<head>	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Riwayat Pemesanan</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<link rel="icon" type="image/png" href="image/tobatransbiru.png">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="jquery/jquery-3.2.1.min.js">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script src="bootstrap/js/bootstrap.min.js"></script>


	<!--  -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/ajax/libs/jquery/3.2.1/jquery.min.js">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 	
<!--  -->
<style type="text/css">
	img
</style>
</head>
<body>
	<?php 
	require_once("header.php");
	?>
	<center>
		<h2>
			Riwayat Pemesanan
		</h2>
		<br>
	</center>
<div class="container">           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Plat Nomor</th>
        <th>Nama Driver</th>
        <th>Tujuan</th>
        <th>Total Transaksi</th>
        <th>Jenis Jasa</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>ewr</th>
        <th>de</th>
        <th>me</th>
        <th>342</th>
        <th>asd</th>
        <th><button>View</button></th>
      </tr>
    </tbody>
  </table>
</div>
</section>
	<?php 
	require_once ("footer.php");
	 ?>
</body>
</html>